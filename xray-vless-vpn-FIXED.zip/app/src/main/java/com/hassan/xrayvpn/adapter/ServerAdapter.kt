package com.hassan.xrayvpn.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.hassan.xrayvpn.R
import com.hassan.xrayvpn.db.ServerEntity

class ServerAdapter(
    private val onSelect: (ServerEntity) -> Unit,
    private val onDelete: (ServerEntity) -> Unit
) : RecyclerView.Adapter<ServerAdapter.ServerViewHolder>() {

    private var items = emptyList<ServerEntity>()

    fun submitList(list: List<ServerEntity>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_server, parent, false)
        return ServerViewHolder(view)
    }

    override fun onBindViewHolder(holder: ServerViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class ServerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tvServerName)
        private val tvProtocol: TextView = itemView.findViewById(R.id.tvServerProtocol)
        private val btnDelete: ImageButton = itemView.findViewById(R.id.btnDeleteServer)
        private val ivCheck: ImageView = itemView.findViewById(R.id.ivSelectedCheck)

        fun bind(server: ServerEntity) {
            tvName.text = server.name
            tvProtocol.text = "${server.protocol.uppercase()} - ${server.address}:${server.port}"
            ivCheck.visibility = if (server.isSelected) View.VISIBLE else View.GONE

            itemView.setOnClickListener { onSelect(server) }
            btnDelete.setOnClickListener { onDelete(server) }
        }
    }
}
