package com.hassan.xrayvpn

data class VlessConfig(
    val address: String,
    val port: Int,
    val id: String,
    val network: String = "tcp",
    val security: String = "reality",
    val sni: String,
    val pbk: String,
    val sid: String = ""
)
