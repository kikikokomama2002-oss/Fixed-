# Xray VLESS / Trojan VPN (Complete UI & Database Edition)

Application complete source code with UI, Room Database, Config Parser, and Connection State Management.

## Features Included
- Dark modern Material UI.
- Circular Power Button with dynamic connection status (Disconnected, Connecting, Connected).
- Config Parser for `vless://` and `trojan://` links.
- Room Database for storing and choosing servers.
- Dynamic Xray JSON configuration generator.
- Settings Screen UI.
