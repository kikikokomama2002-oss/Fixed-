package com.hassan.xrayvpn

import com.hassan.xrayvpn.db.ServerEntity
import org.json.JSONArray
import org.json.JSONObject

class XrayConfigBuilder {

    fun buildConfig(server: ServerEntity): String {
        val root = JSONObject()

        val inbound = JSONObject().apply {
            put("port", 10808)
            put("listen", "127.0.0.1")
            put("protocol", "socks")
        }
        root.put("inbounds", JSONArray().put(inbound))

        val outbound = JSONObject()
        outbound.put("protocol", server.protocol)

        val settings = JSONObject()
        val vnext = JSONObject().apply {
            put("address", server.address)
            put("port", server.port)
            val user = JSONObject().apply {
                put("id", server.uuid)
                put("encryption", "none")
            }
            put("users", JSONArray().put(user))
        }
        settings.put("vnext", JSONArray().put(vnext))
        outbound.put("settings", settings)

        val streamSettings = JSONObject().apply {
            put("network", "tcp")
            if (server.pbk.isNotEmpty()) {
                put("security", "reality")
                val realitySettings = JSONObject().apply {
                    put("serverName", server.sni)
                    put("publicKey", server.pbk)
                    put("shortId", server.sid)
                    put("fingerprint", "chrome")
                }
                put("realitySettings", realitySettings)
            } else if (server.sni.isNotEmpty()) {
                put("security", "tls")
                val tlsSettings = JSONObject().apply {
                    put("serverName", server.sni)
                }
                put("tlsSettings", tlsSettings)
            }
        }
        outbound.put("streamSettings", streamSettings)

        root.put("outbounds", JSONArray().put(outbound))

        return root.toString(2)
    }
}
