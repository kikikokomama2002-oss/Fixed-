package com.hassan.xrayvpn.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hassan.xrayvpn.db.AppDatabase
import com.hassan.xrayvpn.db.ServerEntity
import com.hassan.xrayvpn.parser.ConfigParser
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getDatabase(application).serverDao()

    val servers: StateFlow<List<ServerEntity>> = dao.getAllServers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedServer: StateFlow<ServerEntity?> = dao.getSelectedServer()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun addServerFromUrl(url: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val parsed = ConfigParser.parse(url)
            if (parsed != null) {
                val id = dao.insertServer(parsed)
                if (selectedServer.value == null) {
                    dao.setActiveServer(id)
                }
                onResult(true)
            } else {
                onResult(false)
            }
        }
    }

    fun selectServer(server: ServerEntity) {
        viewModelScope.launch {
            dao.setActiveServer(server.id)
        }
    }

    fun deleteServer(server: ServerEntity) {
        viewModelScope.launch {
            dao.deleteServer(server)
        }
    }
}
