package com.hassan.xrayvpn.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "servers")
data class ServerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val protocol: String,
    val fullUrl: String,
    val address: String,
    val port: Int,
    val uuid: String,
    val sni: String,
    val pbk: String = "",
    val sid: String = "",
    val isSelected: Boolean = false
)
