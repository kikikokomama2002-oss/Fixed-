package com.hassan.xrayvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import com.hassan.xrayvpn.model.ConnectionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

class XrayVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var xrayStarted = false

    companion object {
        const val ACTION_CONNECT = "com.hassan.xrayvpn.CONNECT"
        const val ACTION_DISCONNECT = "com.hassan.xrayvpn.DISCONNECT"
        const val EXTRA_SERVER_CONFIG = "extra_server_config"

        private const val NOTIF_CHANNEL_ID = "xray_vpn_channel"
        private const val NOTIF_ID = 1

        private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
        val connectionState: StateFlow<ConnectionState> = _connectionState
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("معطّل"))

        when (intent?.action) {
            ACTION_CONNECT -> {
                val config = intent.getStringExtra(EXTRA_SERVER_CONFIG)
                connectVpn(config)
            }
            ACTION_DISCONNECT -> {
                disconnectVpn()
            }
        }
        return START_STICKY
    }

    private fun connectVpn(configJson: String?) {
        if (configJson.isNullOrEmpty()) {
            Log.e("XrayVpnService", "لم يتم توفير إعدادات الخادم")
            _connectionState.value = ConnectionState.DISCONNECTED
            return
        }

        _connectionState.value = ConnectionState.CONNECTING
        updateNotification("جاري الاتصال...")

        try {
            // حفظ الإعدادات في ملف
            val configFile = File(filesDir, "xray_config.json")
            configFile.writeText(configJson)
            Log.d("XrayVpnService", "تم حفظ الإعدادات في ${configFile.absolutePath}")

            // فتح واجهة TUN
            val builder = Builder()
                .setSession("XrayVLESSVPN")
                .setMtu(1500)
                .addAddress("10.0.0.2", 24)
                .addDnsServer("8.8.8.8")
                .addDnsServer("1.1.1.1")
                .addRoute("0.0.0.0", 0)

            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                throw Exception("فشل فتح واجهة VPN")
            }
            Log.d("XrayVpnService", "تم فتح واجهة TUN بنجاح")

            // تشغيل Xray-core
            xrayStarted = startXrayCore(configFile.absolutePath)
            
            if (!xrayStarted) {
                Log.w("XrayVpnService", "تحذير: لم يتم تشغيل Xray-core بنجاح")
                // نستمر على أي حال - قد تعمل بعض الوظائف الأساسية
            }

            // محاولة تشغيل tun2socks إذا كان موجود
            try {
                startTun2Socks()
            } catch (e: Exception) {
                Log.d("XrayVpnService", "tun2socks غير متوفر: ${e.message}")
            }

            _connectionState.value = ConnectionState.CONNECTED
            updateNotification("متصل")
            Log.d("XrayVpnService", "تم الاتصال بنجاح")
        } catch (e: Exception) {
            Log.e("XrayVpnService", "خطأ في بدء VPN: ${e.message}", e)
            _connectionState.value = ConnectionState.DISCONNECTED
            cleanupInterface()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun startXrayCore(configPath: String): Boolean {
        val possibleClasses = listOf(
            "com.v2ray.Xray",
            "com.v2ray.core.Xray",
            "libv2ray.Libv2ray",
            "io.v2ray.Xray"
        )

        for (className in possibleClasses) {
            try {
                Log.d("XrayVpnService", "محاولة: $className")
                val xrayClass = Class.forName(className)
                
                val method = try {
                    xrayClass.getMethod("RunXray", String::class.java)
                } catch (e: NoSuchMethodException) {
                    try {
                        xrayClass.getMethod("runXray", String::class.java)
                    } catch (e2: NoSuchMethodException) {
                        xrayClass.getMethod("start", String::class.java)
                    }
                }
                
                method.invoke(null, configPath)
                Log.d("XrayVpnService", "✓ تم تشغيل Xray من $className")
                return true
            } catch (e: Exception) {
                Log.d("XrayVpnService", "✗ فشل مع $className: ${e.javaClass.simpleName}")
            }
        }
        return false
    }

    private fun startTun2Socks() {
        val possibleClasses = listOf(
            "com.v2ray.core.Tun2Socks",
            "libv2ray.Tun2Socks"
        )

        for (className in possibleClasses) {
            try {
                val tun2socksClass = Class.forName(className)
                val method = try {
                    tun2socksClass.getMethod(
                        "start",
                        ParcelFileDescriptor::class.java,
                        String::class.java,
                        Int::class.java
                    )
                } catch (e: NoSuchMethodException) {
                    tun2socksClass.getMethod(
                        "Start",
                        ParcelFileDescriptor::class.java,
                        String::class.java,
                        Int::class.java
                    )
                }

                method.invoke(
                    null,
                    vpnInterface?.fileDescriptor,
                    "127.0.0.1",
                    10808
                )
                Log.d("XrayVpnService", "✓ تم تشغيل tun2socks من $className")
                return
            } catch (e: Exception) {
                Log.d("XrayVpnService", "✗ فشل tun2socks: ${e.javaClass.simpleName}")
            }
        }
    }

    private fun disconnectVpn() {
        _connectionState.value = ConnectionState.DISCONNECTING
        updateNotification("جاري قطع الاتصال...")
        try {
            // محاولة إيقاف Xray
            if (xrayStarted) {
                try {
                    val xrayClass = Class.forName("com.v2ray.Xray")
                    val method = try {
                        xrayClass.getMethod("StopXray")
                    } catch (e: NoSuchMethodException) {
                        xrayClass.getMethod("stopXray")
                    }
                    method.invoke(null)
                    Log.d("XrayVpnService", "✓ تم إيقاف Xray")
                } catch (e: Exception) {
                    Log.d("XrayVpnService", "✗ خطأ في إيقاف Xray")
                }
            }

            cleanupInterface()
            Log.d("XrayVpnService", "تم قطع الاتصال")
        } catch (e: Exception) {
            Log.e("XrayVpnService", "خطأ في إيقاف VPN", e)
        } finally {
            _connectionState.value = ConnectionState.DISCONNECTED
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun cleanupInterface() {
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e("XrayVpnService", "خطأ في إغلاق TUN", e)
        } finally {
            vpnInterface = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL_ID,
                "حالة VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "حالة اتصال Xray VPN"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val openAppIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return Notification.Builder(this, NOTIF_CHANNEL_ID).apply {
            setContentTitle("Xray VPN")
            setContentText(statusText)
            setSmallIcon(R.drawable.ic_power)
            setContentIntent(pendingIntent)
            setOngoing(true)
        }.build()
    }

    private fun updateNotification(statusText: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIF_ID, buildNotification(statusText))
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnectVpn()
    }

    override fun onRevoke() {
        super.onRevoke()
        disconnectVpn()
    }
}
