package com.hassan.xrayvpn

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.hassan.xrayvpn.adapter.ServerAdapter
import com.hassan.xrayvpn.model.ConnectionState
import com.hassan.xrayvpn.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private val configBuilder = XrayConfigBuilder()

    private lateinit var btnConnectContainer: FrameLayout
    private lateinit var ivPower: ImageView
    private lateinit var tvStatus: TextView
    private lateinit var tvActiveServerName: TextView
    private lateinit var tvActiveServerProtocol: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        observeViewModel()
        observeVpnState()
    }

    private fun initViews() {
        btnConnectContainer = findViewById(R.id.btnConnectContainer)
        ivPower = findViewById(R.id.ivPower)
        tvStatus = findViewById(R.id.tvStatus)
        tvActiveServerName = findViewById(R.id.tvActiveServerName)
        tvActiveServerProtocol = findViewById(R.id.tvActiveServerProtocol)

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<ImageButton>(R.id.btnAddServer).setOnClickListener {
            showAddServerDialog()
        }

        findViewById<FrameLayout>(R.id.cardServer).setOnClickListener {
            showServerListBottomSheet()
        }

        btnConnectContainer.setOnClickListener {
            toggleVpnConnection()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.selectedServer.collectLatest { server ->
                if (server != null) {
                    tvActiveServerName.text = server.name
                    tvActiveServerProtocol.text = "${server.protocol.uppercase()} - ${server.address}:${server.port}"
                } else {
                    tvActiveServerName.text = "No Server Selected"
                    tvActiveServerProtocol.text = "Tap + to add VLESS / Trojan link"
                }
            }
        }
    }

    private fun observeVpnState() {
        lifecycleScope.launch {
            XrayVpnService.connectionState.collectLatest { state ->
                updateUiForState(state)
            }
        }
    }

    private fun updateUiForState(state: ConnectionState) {
        when (state) {
            ConnectionState.DISCONNECTED -> {
                tvStatus.text = "Disconnected"
                tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_disconnected))
                ivPower.imageTintList = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
            }
            ConnectionState.CONNECTING -> {
                tvStatus.text = "Connecting..."
                tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_connecting))
                ivPower.imageTintList = ColorStateList.valueOf(Color.parseColor("#FFB300"))
            }
            ConnectionState.CONNECTED -> {
                tvStatus.text = "Connected"
                tvStatus.setTextColor(ContextCompat.getColor(this, R.color.primary_accent))
                ivPower.imageTintList = ColorStateList.valueOf(Color.parseColor("#00E676"))
            }
            ConnectionState.DISCONNECTING -> {
                tvStatus.text = "Disconnecting..."
                tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_connecting))
            }
        }
    }

    private fun toggleVpnConnection() {
        val currentState = XrayVpnService.connectionState.value
        if (currentState == ConnectionState.CONNECTED || currentState == ConnectionState.CONNECTING) {
            val intent = Intent(this, XrayVpnService::class.java).apply {
                action = XrayVpnService.ACTION_DISCONNECT
            }
            startService(intent)
        } else {
            val server = viewModel.selectedServer.value
            if (server == null) {
                Toast.makeText(this, "Please select or add a server first!", Toast.LENGTH_SHORT).show()
                return
            }

            val vpnIntent = VpnService.prepare(this)
            if (vpnIntent != null) {
                startActivityForResult(vpnIntent, 100)
            } else {
                startVpnService(server)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val server = viewModel.selectedServer.value
            if (server != null) {
                startVpnService(server)
            }
        }
    }

    private fun startVpnService(server: com.hassan.xrayvpn.db.ServerEntity) {
        val configJson = configBuilder.buildConfig(server)
        val intent = Intent(this, XrayVpnService::class.java).apply {
            action = XrayVpnService.ACTION_CONNECT
            putExtra(XrayVpnService.EXTRA_SERVER_CONFIG, configJson)
        }
        startService(intent)
    }

    private fun showAddServerDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_add_server, null)
        val etUrl = view.findViewById<EditText>(R.id.etServerUrl)
        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        view.findViewById<Button>(R.id.btnCancel).setOnClickListener { dialog.dismiss() }
        view.findViewById<Button>(R.id.btnAdd).setOnClickListener {
            val url = etUrl.text.toString()
            if (url.isNotEmpty()) {
                viewModel.addServerFromUrl(url) { success ->
                    if (success) {
                        Toast.makeText(this, "Server added successfully", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                    } else {
                        Toast.makeText(this, "Invalid VLESS or Trojan URL", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun showServerListBottomSheet() {
        val dialog = BottomSheetDialog(this)
        val recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.parseColor("#121212"))
        }

        val adapter = ServerAdapter(
            onSelect = { server ->
                viewModel.selectServer(server)
                dialog.dismiss()
            },
            onDelete = { server ->
                viewModel.deleteServer(server)
            }
        )

        recyclerView.adapter = adapter
        dialog.setContentView(recyclerView)

        lifecycleScope.launch {
            viewModel.servers.collectLatest { list ->
                adapter.submitList(list)
            }
        }

        dialog.show()
    }
}
