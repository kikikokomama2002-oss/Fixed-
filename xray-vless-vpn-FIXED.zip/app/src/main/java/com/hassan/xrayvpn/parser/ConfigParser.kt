package com.hassan.xrayvpn.parser

import com.hassan.xrayvpn.db.ServerEntity
import java.net.URI
import java.net.URLDecoder

object ConfigParser {

    fun parse(rawUrl: String): ServerEntity? {
        val trimmed = rawUrl.trim()
        return when {
            trimmed.startsWith("vless://") -> parseVless(trimmed)
            trimmed.startsWith("trojan://") -> parseTrojan(trimmed)
            else -> null
        }
    }

    private fun parseVless(url: String): ServerEntity? {
        return try {
            val uri = URI(url)
            val uuid = uri.userInfo ?: ""
            val host = uri.host ?: ""
            val port = if (uri.port != -1) uri.port else 443
            val fragment = if (uri.fragment != null) URLDecoder.decode(uri.fragment, "UTF-8") else "VLESS Server"

            var sni = ""
            var pbk = ""
            var sid = ""

            uri.query?.split("&")?.forEach { param ->
                val parts = param.split("=")
                if (parts.size == 2) {
                    when (parts[0].lowercase()) {
                        "sni" -> sni = URLDecoder.decode(parts[1], "UTF-8")
                        "pbk" -> pbk = URLDecoder.decode(parts[1], "UTF-8")
                        "sid" -> sid = URLDecoder.decode(parts[1], "UTF-8")
                    }
                }
            }

            ServerEntity(
                name = fragment,
                protocol = "vless",
                fullUrl = url,
                address = host,
                port = port,
                uuid = uuid,
                sni = sni,
                pbk = pbk,
                sid = sid
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun parseTrojan(url: String): ServerEntity? {
        return try {
            val uri = URI(url)
            val password = uri.userInfo ?: ""
            val host = uri.host ?: ""
            val port = if (uri.port != -1) uri.port else 443
            val fragment = if (uri.fragment != null) URLDecoder.decode(uri.fragment, "UTF-8") else "Trojan Server"

            var sni = host
            uri.query?.split("&")?.forEach { param ->
                val parts = param.split("=")
                if (parts.size == 2 && parts[0].lowercase() == "sni") {
                    sni = URLDecoder.decode(parts[1], "UTF-8")
                }
            }

            ServerEntity(
                name = fragment,
                protocol = "trojan",
                fullUrl = url,
                address = host,
                port = port,
                uuid = password,
                sni = sni
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
